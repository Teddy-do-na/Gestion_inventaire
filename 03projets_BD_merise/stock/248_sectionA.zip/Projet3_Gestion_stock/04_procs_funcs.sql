-- 04_procs_funcs.sql
-- Ce fichier montre comment les appeler et inclut une procédure supplémentaire d'exemple.

SET search_path TO sm, public;

-- Exemple d'appel:
CALL sm.pr_ajouter_commande(1, 3, 'EN_COURS');
SELECT sm.fn_produit_disponible(1, 10);

-- Procédure annexe: livrer une commande (changement de statut)
CREATE OR REPLACE PROCEDURE sm.pr_livrer_commande(p_id_commande BIGINT)
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE commandes
     SET statut = 'LIVREE'
   WHERE id_commande = p_id_commande
     AND statut = 'EN_COURS';

  IF NOT FOUND THEN
     RAISE NOTICE 'Aucune commande EN_COURS trouvée avec id=%', p_id_commande;
  END IF;
END;
$$;
