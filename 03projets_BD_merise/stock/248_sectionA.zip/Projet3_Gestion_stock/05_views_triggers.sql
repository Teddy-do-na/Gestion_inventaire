-- 05_views_triggers.sql
-- Vue déjà créée: sm.vw_details_commandes
-- Triggers déjà créés: sm.trg_commandes_maj_stock (insert/delete/update), sm.trg_produits_set_date_maj

SET search_path TO sm, public;

-- Afficher les détails des commandes
SELECT * FROM sm.vw_details_commandes ORDER BY date_commande DESC;

-- Vérifications rapides du trigger de stock:
-- 1) Stock avant
SELECT id_produit, nom, stock FROM produits WHERE nom='Riz 5kg';
-- 2) Insertion commande
CALL sm.pr_ajouter_commande((SELECT id_produit FROM produits WHERE nom='Riz 5kg'), 2, 'EN_COURS');
-- 3) Stock après
SELECT id_produit, nom, stock FROM produits WHERE nom='Riz 5kg';
-- 4) Suppression de la commande (reprend le stock)
DELETE FROM commandes WHERE id_commande = (SELECT max(id_commande) FROM commandes WHERE id_produit = (SELECT id_produit FROM produits WHERE nom='Riz 5kg'));
-- 5) Stock restauré
SELECT id_produit, nom, stock FROM produits WHERE nom='Riz 5kg';
