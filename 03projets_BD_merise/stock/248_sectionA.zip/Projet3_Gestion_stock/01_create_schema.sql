-- 01_create_schema.sql
-- 1) Schéma dédié
CREATE SCHEMA IF NOT EXISTS sm AUTHORIZATION CURRENT_USER;
SET search_path TO sm, public;

-- 2) Tables de référence
CREATE TABLE IF NOT EXISTS categories (
    id_categorie      SMALLINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    nom_categorie     VARCHAR(80) NOT NULL UNIQUE,
    description       TEXT
);

CREATE TABLE IF NOT EXISTS fournisseurs (
    id_fournisseur    SMALLINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    nom               VARCHAR(120) NOT NULL,
    contact           VARCHAR(120),
    adresse           TEXT,
    telephone         VARCHAR(30),
    CONSTRAINT uq_fournisseur_nom_contact UNIQUE (nom, contact)
);

-- 3) Table produits
CREATE TABLE IF NOT EXISTS produits (
    id_produit        BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    nom               VARCHAR(160) NOT NULL,
    description       TEXT,
    prix              NUMERIC(12,2) NOT NULL DEFAULT 0 CHECK (prix >= 0),
    stock             INTEGER NOT NULL DEFAULT 0 CHECK (stock >= 0),
    id_categorie      SMALLINT NOT NULL,
    id_fournisseur    SMALLINT NOT NULL,
    actif             BOOLEAN NOT NULL DEFAULT TRUE,
    date_creation     TIMESTAMP NOT NULL DEFAULT NOW(),
    date_maj          TIMESTAMP NOT NULL DEFAULT NOW(),
    CONSTRAINT fk_produits_categorie   FOREIGN KEY (id_categorie)   REFERENCES categories (id_categorie) ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_produits_fournisseur FOREIGN KEY (id_fournisseur) REFERENCES fournisseurs (id_fournisseur) ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT uq_produit_nom_fourn UNIQUE (nom, id_fournisseur)
);

CREATE INDEX IF NOT EXISTS idx_produits_categorie ON produits(id_categorie);
CREATE INDEX IF NOT EXISTS idx_produits_fournisseur ON produits(id_fournisseur);

-- 4) Table commandes
-- On ajoute un statut pour distinguer EN_COURS / LIVREE / ANNULEE (extension utile pour les requêtes)
CREATE TABLE IF NOT EXISTS commandes (
    id_commande       BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    id_produit        BIGINT NOT NULL,
    quantite          INTEGER NOT NULL CHECK (quantite > 0),
    date_commande     TIMESTAMP NOT NULL DEFAULT NOW(),
    statut            VARCHAR(12) NOT NULL DEFAULT 'EN_COURS' CHECK (statut IN ('EN_COURS','LIVREE','ANNULEE')),
    CONSTRAINT fk_commandes_produit FOREIGN KEY (id_produit) REFERENCES produits (id_produit) ON UPDATE CASCADE ON DELETE RESTRICT
);

CREATE INDEX IF NOT EXISTS idx_commandes_produit ON commandes(id_produit);
CREATE INDEX IF NOT EXISTS idx_commandes_statut  ON commandes(statut);

-- 5) Trigger d'horodatage produits (maj automatique)
CREATE OR REPLACE FUNCTION sm._set_produits_date_maj()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  NEW.date_maj := NOW();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_produits_set_date_maj ON produits;
CREATE TRIGGER trg_produits_set_date_maj
BEFORE UPDATE ON produits
FOR EACH ROW
EXECUTE FUNCTION sm._set_produits_date_maj();

-- 6) Fonction utilitaire: vérifier la disponibilité
CREATE OR REPLACE FUNCTION sm.fn_produit_disponible(p_id_produit BIGINT, p_qte INTEGER)
RETURNS BOOLEAN
LANGUAGE plpgsql
AS $$
DECLARE
  v_stock INTEGER;
BEGIN
  IF p_qte IS NULL OR p_qte <= 0 THEN
     RETURN FALSE;
  END IF;

  SELECT stock INTO v_stock FROM produits WHERE id_produit = p_id_produit AND actif = TRUE;
  IF NOT FOUND THEN
     RETURN FALSE;
  END IF;

  RETURN v_stock >= p_qte;
END;
$$;

-- 7) Procédure: ajouter une commande avec contrôle de stock
CREATE OR REPLACE PROCEDURE sm.pr_ajouter_commande(p_id_produit BIGINT, p_qte INTEGER, p_statut VARCHAR(12) DEFAULT 'EN_COURS')
LANGUAGE plpgsql
AS $$
BEGIN
  IF p_qte IS NULL OR p_qte <= 0 THEN
     RAISE EXCEPTION 'Quantité invalide (%)', p_qte USING ERRCODE = '22023';
  END IF;

  IF NOT sm.fn_produit_disponible(p_id_produit, p_qte) THEN
     RAISE EXCEPTION 'Stock insuffisant pour le produit % (demande=%)', p_id_produit, p_qte USING ERRCODE = 'P0001';
  END IF;

  INSERT INTO commandes (id_produit, quantite, statut)
  VALUES (p_id_produit, p_qte, COALESCE(p_statut,'EN_COURS'));

  -- La décrémentation du stock sera gérée par le trigger sur commandes (voir plus bas).
END;
$$;

-- 8) Vue: détails des commandes
CREATE OR REPLACE VIEW sm.vw_details_commandes AS
SELECT
  c.id_commande,
  p.id_produit,
  p.nom AS produit,
  f.nom AS fournisseur,
  c.quantite,
  c.date_commande,
  c.statut,
  p.prix,
  (c.quantite * p.prix) AS montant
FROM commandes c
JOIN produits   p ON p.id_produit = c.id_produit
JOIN fournisseurs f ON f.id_fournisseur = p.id_fournisseur;

-- 9) Triggers de stock sur commandes
CREATE OR REPLACE FUNCTION sm._maj_stock_apres_commande()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
     UPDATE produits SET stock = stock - NEW.quantite WHERE id_produit = NEW.id_produit;
     IF NOT sm.fn_produit_disponible(NEW.id_produit, 0) THEN
       -- validation: le stock ne doit pas devenir négatif
       IF (SELECT stock FROM produits WHERE id_produit = NEW.id_produit) < 0 THEN
         RAISE EXCEPTION 'Stock négatif non autorisé pour le produit %', NEW.id_produit;
       END IF;
     END IF;
     RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
     UPDATE produits SET stock = stock + OLD.quantite WHERE id_produit = OLD.id_produit;
     RETURN OLD;
  ELSIF TG_OP = 'UPDATE' THEN
     -- si on change la quantité ou le produit, on réajuste
     IF NEW.id_produit = OLD.id_produit THEN
        UPDATE produits
           SET stock = stock + (OLD.quantite - NEW.quantite)
         WHERE id_produit = NEW.id_produit;
     ELSE
        UPDATE produits SET stock = stock + OLD.quantite WHERE id_produit = OLD.id_produit;
        UPDATE produits SET stock = stock - NEW.quantite WHERE id_produit = NEW.id_produit;
     END IF;
     IF (SELECT stock FROM produits WHERE id_produit = NEW.id_produit) < 0 THEN
        RAISE EXCEPTION 'Stock négatif non autorisé pour le produit %', NEW.id_produit;
     END IF;
     RETURN NEW;
  END IF;
  RETURN NULL;
END;
$$;

DROP TRIGGER IF EXISTS trg_commandes_maj_stock ON commandes;
CREATE TRIGGER trg_commandes_maj_stock
AFTER INSERT OR DELETE OR UPDATE ON commandes
FOR EACH ROW
EXECUTE FUNCTION sm._maj_stock_apres_commande();

