-- 03_queries.sql
SET search_path TO sm, public;

-- 1) Lister tous les produits d’une catégorie (param: nom_categorie)
CREATE OR REPLACE VIEW vw_produits_par_categorie AS
SELECT p.id_produit, p.nom, p.prix, p.stock, c.nom_categorie, f.nom AS fournisseur
FROM produits p
JOIN categories c   ON c.id_categorie = p.id_categorie
JOIN fournisseurs f ON f.id_fournisseur = p.id_fournisseur;

-- 2) Trouver les fournisseurs d’un produit donné (par nom de produit)
Param: nom_produit
SELECT DISTINCT f.* 
FROM fournisseurs f
JOIN produits p ON p.id_fournisseur = f.id_fournisseur
WHERE p.nom = $1;

-- 3) Lister les commandes en cours pour un produit (par nom de produit)
Param: nom_produit
SELECT c.*
FROM commandes c
JOIN produits p ON p.id_produit = c.id_produit
WHERE p.nom = $1 AND c.statut = 'EN_COURS'
ORDER BY c.date_commande DESC;

-- 4) Compter le nombre total de commandes par produit
-- Agrégat global (toutes commandes, tous statuts)
SELECT p.id_produit, p.nom, COUNT(c.id_commande) AS nb_commandes
FROM produits p
LEFT JOIN commandes c ON c.id_produit = p.id_produit
GROUP BY p.id_produit, p.nom
ORDER BY nb_commandes DESC, p.nom ASC;

-- Exemples de mise à jour / suppression
-- Mettre à jour le prix d’un produit
UPDATE produits SET prix = 720 WHERE nom = 'Pâtes 500g';

-- Mettre à jour un fournisseur
UPDATE fournisseurs SET telephone = '+237690000099' WHERE nom = 'Epicerie&Co';

-- Supprimer une commande spécifique (ex: id_commande=1)
DELETE FROM commandes WHERE id_commande = 1;
