-- 02_insert_data.sql
-- Données fictives de démonstration
SET search_path TO sm, public;

-- === Insertion de données de référence ===
-- Catégories
INSERT INTO categories (nom_categorie, description) VALUES
('Frais',        'Produits frais (laitages, fromages, etc.)'),
('Epicerie',     'Produits secs et conserves'),
('Boissons',     'Eaux, jus, sodas'),
('Hygiène',      'Hygiène et entretien'),
('Boulangerie',  'Pains et viennoiseries')
ON CONFLICT DO NOTHING;

-- Fournisseurs
INSERT INTO fournisseurs (nom, contact, adresse, telephone) VALUES
('AgriFourn SA',    'contact@agrifourn.example', 'Zone Indus A', '+237690000001'),
('Epicerie&Co',     'ventes@epicerieco.example',  'Quartier B',   '+237690000002'),
('BoissonsPlus',    'info@boissonsplus.example',  'Zone Indus C', '+237690000003'),
('MaisonClean',     'support@maisonclean.example','Quartier D',   '+237690000004')
ON CONFLICT DO NOTHING;

-- Produits
INSERT INTO produits (nom, description, prix, stock, id_categorie, id_fournisseur) VALUES
('Lait UHT 1L',        'Lait demi-écrémé',                       850,   120, (SELECT id_categorie FROM categories WHERE nom_categorie='Frais'),     (SELECT id_fournisseur FROM fournisseurs WHERE nom='AgriFourn SA')),
('Fromage Brie 200g',  'Fromage brie',                           2100,   60, (SELECT id_categorie FROM categories WHERE nom_categorie='Frais'),     (SELECT id_fournisseur FROM fournisseurs WHERE nom='AgriFourn SA')),
('Riz 5kg',            'Riz parfumé 5 kg',                       6500,   90, (SELECT id_categorie FROM categories WHERE nom_categorie='Epicerie'),   (SELECT id_fournisseur FROM fournisseurs WHERE nom='Epicerie&Co')),
('Pâtes 500g',         'Pâtes penne 500g',                        700,  300, (SELECT id_categorie FROM categories WHERE nom_categorie='Epicerie'),   (SELECT id_fournisseur FROM fournisseurs WHERE nom='Epicerie&Co')),
('Eau Minérale 1.5L',  'Pack de 6 bouteilles',                   1800,  200, (SELECT id_categorie FROM categories WHERE nom_categorie='Boissons'),   (SELECT id_fournisseur FROM fournisseurs WHERE nom='BoissonsPlus')),
('Soda Cola 33cl',     'Canette 33cl',                            500,  400, (SELECT id_categorie FROM categories WHERE nom_categorie='Boissons'),   (SELECT id_fournisseur FROM fournisseurs WHERE nom='BoissonsPlus')),
('Savon Liquide 500ml','Savon pour les mains 500ml',              950,  150, (SELECT id_categorie FROM categories WHERE nom_categorie='Hygiène'),    (SELECT id_fournisseur FROM fournisseurs WHERE nom='MaisonClean')),
('Eau de Javel 1L',    'Nettoyant désinfectant 1L',               700,  180, (SELECT id_categorie FROM categories WHERE nom_categorie='Hygiène'),    (SELECT id_fournisseur FROM fournisseurs WHERE nom='MaisonClean')),
('Baguette',           'Pain baguette fraîche du jour',           250,  100, (SELECT id_categorie FROM categories WHERE nom_categorie='Boulangerie'),(SELECT id_fournisseur FROM fournisseurs WHERE nom='AgriFourn SA'))
ON CONFLICT DO NOTHING;

-- === Procédure wrapper pour ajouter une commande à partir du nom produit ===
CREATE OR REPLACE PROCEDURE sm.pr_ajouter_commande_nom(
    p_nom TEXT,
    p_qte INTEGER,
    p_statut VARCHAR(12) DEFAULT 'EN_COURS')
LANGUAGE plpgsql AS $$
DECLARE
  v_id BIGINT;
BEGIN
  SELECT id_produit INTO v_id FROM produits WHERE nom = p_nom;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Produit % introuvable', p_nom;
  END IF;

  CALL sm.pr_ajouter_commande(v_id, p_qte, p_statut);
END;
$$;

-- === Commandes fictives ===
CALL sm.pr_ajouter_commande_nom('Riz 5kg', 5, 'EN_COURS');
CALL sm.pr_ajouter_commande_nom('Pâtes 500g', 20, 'EN_COURS');
CALL sm.pr_ajouter_commande_nom('Eau Minérale 1.5L', 12, 'EN_COURS');
